﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace asciitest
{
    class Program
    {
        static void Main(string[] args)
        {
            char test = '■';

            // C O C O C O C 
            Console.Write('Ↄ');
            Console.ReadKey();
        }
    }
}
